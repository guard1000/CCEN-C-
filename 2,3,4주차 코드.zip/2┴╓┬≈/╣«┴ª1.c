#include <stdio.h>

int main(int argc, char* argv[]) {
	int score = 0;
	scanf("%d",&score);
	if(score >= 95){
		printf("A+\n");
	}else if(score >= 90){
		printf("A\n");		
	}else if(score >=85){
		printf("B+\n");
	}else if(score >=80){
		printf("B\n");
	}else if(score >=75){
		printf("C+\n");
	}else if(score >=70){
		printf("C\n");
	}else if(score >=65){
		printf("D+\n");
	}else if(score >=60){
		printf("D\n");
	}else{
		printf("F\n");
	}
	
	return 0;
}