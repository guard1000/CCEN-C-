#include <stdio.h>

int main(int argc, char* argv[]) {
	int a, b, c = 0;
	
	scanf("%d %d %d",&a, &b, &c);
	int temp = 0;
	if(a>b) {
		temp = a;
		a = b;
		b = temp;
	}
	if(a>c) {
		temp = a;
		a = c;
		c = temp;
	}
	if(b>c) {
		temp = b;
		b = c;
		c = temp;
	}
	printf("%d %d %d\n",a,b,c);
	return 0;
}