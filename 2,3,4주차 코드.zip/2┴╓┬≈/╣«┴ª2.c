#include <stdio.h>

int main(int argc, char* argv[]) {
	int a,b=0;
	char op = 0;
	double result = 0;
	
	scanf("%d %c %d",&a,&op,&b);
	if(op == '+'){
		result = a+b;
	}else if(op=='-'){
		result = a-b;
	}else if(op=='*'){
		result = a*b;
	}else if(op=='/'){
		result = a/(float)b;
	}else if(op=='%'){
		result = a%b;
	}
	
	//printf("%d %c %d\n",a,op,b);
	printf("%f\n",result);
	return 0;
}